import requests

url = "http://localhost:11434/api/generate"

payload = {
    "model": "deepseek-coder:6.7b",
    "prompt": "Explain what Jetson Nano is",
    "stream": False
}

r = requests.post(url, json=payload)

print(r.status_code)
print(r.text)