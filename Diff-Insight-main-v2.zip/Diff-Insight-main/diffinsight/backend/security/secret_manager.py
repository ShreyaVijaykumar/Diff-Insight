import os
import hvac


class SecretManager:

    _client = None

    @classmethod
    def _get_client(cls):
        """
        Create or return an authenticated Vault client.
        Strips whitespace from env vars to guard against .env formatting issues.
        """
        if cls._client is None:

            vault_url   = (os.getenv("VAULT_ADDR")  or "").strip()
            vault_token = (os.getenv("VAULT_TOKEN") or "").strip()

            if not vault_url or not vault_token:
                raise RuntimeError(
                    "Vault credentials missing. "
                    "Set VAULT_ADDR and VAULT_TOKEN in your environment or .env file."
                )

            cls._client = hvac.Client(
                url=vault_url,
                token=vault_token
            )

            if not cls._client.is_authenticated():
                cls._client = None
                raise RuntimeError(
                    "Vault authentication failed. "
                    "Check that VAULT_TOKEN is correct and the Vault server is unsealed."
                )

        return cls._client

    @classmethod
    def get_github_token(cls) -> str:
        """
        Retrieve GitHub token from Vault.
        Falls back to GITHUB_TOKEN environment variable if Vault fails.
        """
        try:
            client = cls._get_client()

            secret = client.secrets.kv.v2.read_secret_version(
                path="github",
                mount_point="secret"
            )

            token = secret["data"]["data"]["token"]

            if not token or not token.strip():
                raise RuntimeError("Vault returned an empty GitHub token.")

            return token.strip()

        except Exception as e:
            print(f"Vault error: {e}")

            fallback = (os.getenv("GITHUB_TOKEN") or "").strip()

            if fallback:
                print("Using fallback GITHUB_TOKEN from environment.")
                return fallback

            raise RuntimeError(
                "Failed to retrieve GitHub token from Vault and no GITHUB_TOKEN env var found.\n"
                "Either:\n"
                "  1. Fix your Vault setup (check VAULT_ADDR, VAULT_TOKEN, vault status)\n"
                "  2. Set GITHUB_TOKEN=your_token in your .env file as a fallback"
            )
