import requests
from backend.security.secret_manager import SecretManager

GITHUB_API = "https://api.github.com/search/repositories"

_GITHUB_NATIVE_SORT = {"stars", "forks", "updated"}

MIN_STARS = 50


def search_repositories(query: str, sort: str = "stars", language: str = None) -> list[dict]:
    """
    Fetch the true top-10 repositories for a given query + sort criteria.

    Sort options
    ------------
    stars    – highest GitHub star count             (GitHub native)
    forks    – highest fork count                    (GitHub native)
    updated  – most recently pushed to               (GitHub native)
    issues   – most open issues, re-sorted client-side from top-200 by stars
    watchers – most watchers,    re-sorted client-side from top-200 by stars

    Optional
    --------
    language – filter by programming language e.g. "python", "javascript"
    """

    token = SecretManager.get_github_token()

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    client_side_sort = sort in {"issues", "watchers"}
    github_sort = sort if sort in _GITHUB_NATIVE_SORT else "stars"

    q = query
    if language:
        q += f" language:{language}"
    q += f" stars:>={MIN_STARS}"

    def _fetch_page(page: int, per_page: int) -> list:
        params = {
            "q":        q,
            "sort":     github_sort,
            "order":    "desc",
            "per_page": per_page,
            "page":     page,
        }
        r = requests.get(GITHUB_API, headers=headers, params=params, timeout=10)
        r.raise_for_status()
        return r.json().get("items", [])

    if client_side_sort:
        page1 = _fetch_page(page=1, per_page=100)
        page2 = _fetch_page(page=2, per_page=100)
        items = page1 + page2
    else:
        items = _fetch_page(page=1, per_page=10)

    repos = [
        {
            "name":        repo["full_name"],
            "description": repo.get("description") or "",
            "stars":       repo["stargazers_count"],
            "forks":       repo["forks_count"],
            "issues":      repo["open_issues_count"],
            "watchers":    repo["watchers_count"],
            "updated":     repo["updated_at"],
            "url":         repo["html_url"],
            "language":    repo.get("language") or "N/A",
        }
        for repo in items
    ]

    if sort == "issues":
        repos.sort(key=lambda r: r["issues"], reverse=True)
    elif sort == "watchers":
        repos.sort(key=lambda r: r["watchers"], reverse=True)

    return repos[:10]