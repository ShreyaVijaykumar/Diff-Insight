import requests

OLLAMA_URL = "http://localhost:11434/api/generate"


def ask_ollama(prompt):

    try:

        payload = {
            "model": "deepseek-coder:6.7b",
            "prompt": prompt,
            "stream": False
        }

        response = requests.post(
            OLLAMA_URL,
            json=payload,
            timeout=120
        )

        if response.status_code != 200:
            print("Ollama API error:", response.text)
            return "AI response unavailable"

        data = response.json()

        return data.get("response", "No response from model")

    except Exception as e:
        print("Ollama connection error:", e)
        return "AI response unavailable"