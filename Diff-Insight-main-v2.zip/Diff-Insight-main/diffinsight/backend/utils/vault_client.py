import subprocess
import json


def get_github_token():
    try:
        result = subprocess.run(
            ["vault", "kv", "get", "-format=json", "secret/github"],
            capture_output=True,
            text=True,
        )

        data = json.loads(result.stdout)

        return data["data"]["data"]["token"]

    except Exception as e:
        print("Vault token error:", e)
        return None