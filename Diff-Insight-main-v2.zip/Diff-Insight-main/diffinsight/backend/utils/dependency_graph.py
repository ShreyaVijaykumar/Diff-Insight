import ast
import re
import networkx as nx


def extract_code_from_diff(diff_text: str) -> str:
    """
    Pull added and context lines from a unified git diff,
    strip all diff markers, and return clean Python source.

    Git diff line prefixes:
      '+'  → added line   → strip '+', keep
      '-'  → removed line → skip entirely
      ' '  → context line → strip the leading space, keep
      '@@' → hunk header  → skip
      '---'/'+++' → file header → skip
      'diff '/'index ' → git header → skip
    """
    code_lines = []

    for line in diff_text.splitlines():
        # Git and file headers — skip
        if line.startswith('diff '):   continue
        if line.startswith('index '):  continue
        if line.startswith('--- '):    continue
        if line.startswith('+++ '):    continue
        if line.startswith('@@'):      continue

        if line.startswith('+'):
            # Added line — strip the leading '+'
            code_lines.append(line[1:])

        elif line.startswith('-'):
            # Removed line — skip, we only graph what's being added
            continue

        elif line.startswith(' '):
            # Context line — MUST strip the leading space or ast.parse
            # will see unexpected indentation and fail immediately
            code_lines.append(line[1:])

        else:
            # Bare line with no prefix (shouldn't normally appear) — keep as-is
            code_lines.append(line)

    return "\n".join(code_lines)


def _is_parseable_python(code: str) -> bool:
    """
    Quick check — does the extracted code contain Python-like constructs?
    Avoids running ast.parse on shell scripts, YAML, JS diffs, etc.
    """
    python_signals = [
        r'^\s*def ',
        r'^\s*async def ',
        r'^\s*class ',
        r'^\s*import ',
        r'^\s*from\s+\S+\s+import',
        r'^\s*@\w+',            # decorators like @app.get, @staticmethod
    ]
    for line in code.splitlines():
        for pattern in python_signals:
            if re.match(pattern, line):
                return True
    return False


def build_dependency_graph_from_diff(diff_text: str) -> nx.DiGraph:
    """
    Parse the Python code extracted from a git diff and build a directed
    dependency graph of imports, functions, classes and their call relationships.

    Returns an empty DiGraph (never None) if:
      - diff is empty
      - no Python constructs found
      - AST parsing fails after retries
    """
    graph = nx.DiGraph()

    if not diff_text or not diff_text.strip():
        print("Dependency graph: empty diff.")
        return graph

    code = extract_code_from_diff(diff_text)

    if not code.strip():
        print("Dependency graph: no code extracted from diff.")
        return graph

    if not _is_parseable_python(code):
        print("Dependency graph: no Python constructs found in diff.")
        return graph

    # ── AST parse ────────────────────────────────────────────────────────────
    tree = None

    try:
        tree = ast.parse(code)
        print(f"Dependency graph: AST parse successful ({len(code.splitlines())} lines).")

    except SyntaxError as e:
        print(f"Dependency graph: SyntaxError ({e}), retrying with only added lines.")

        # Retry using only '+' lines — strips all context which may have
        # inconsistent indentation across hunks
        added_only = "\n".join(
            line[1:]
            for line in diff_text.splitlines()
            if line.startswith('+')
            and not line.startswith('+++')
        )

        try:
            tree = ast.parse(added_only)
            print("Dependency graph: retry parse successful.")
        except SyntaxError as e2:
            print(f"Dependency graph: retry also failed ({e2}), returning empty graph.")
            return graph

    except Exception as e:
        print(f"Dependency graph: unexpected error ({e}), returning empty graph.")
        return graph

    # ── Walk the AST ─────────────────────────────────────────────────────────
    current_function = None

    for node in ast.walk(tree):

        if isinstance(node, ast.Import):
            for alias in node.names:
                graph.add_edge("FILE", alias.name)

        elif isinstance(node, ast.ImportFrom):
            if node.module:
                graph.add_edge("FILE", node.module)

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            current_function = node.name
            graph.add_edge("FILE", current_function)

        elif isinstance(node, ast.ClassDef):
            graph.add_edge("FILE", node.name)
            current_function = node.name

        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                called = node.func.id
                if current_function:
                    graph.add_edge(current_function, called)
                else:
                    graph.add_edge("FILE", called)

            elif isinstance(node.func, ast.Attribute):
                called = node.func.attr
                if current_function:
                    graph.add_edge(current_function, called)
                else:
                    graph.add_edge("FILE", called)

    # Remove self-loops (e.g. a function that calls itself gets a separate edge,
    # but FILE->FILE from bare module-level calls is noise)
    graph.remove_edges_from(list(nx.selfloop_edges(graph)))

    print(f"Dependency graph: built — {len(graph.nodes)} nodes, {len(graph.edges)} edges.")
    return graph