from pathlib import Path
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import networkx as nx
import time

# Resolve STATIC_DIR relative to CWD (where uvicorn is launched from)
# so the saved PNG ends up in the same frontend/static that FastAPI serves.
def _get_static_dir() -> Path:
    # Try CWD-relative path first (most reliable when running from project root)
    cwd_static = Path(os.getcwd()) / "frontend" / "static"
    if cwd_static.exists():
        return cwd_static

    # Fallback: walk up from this file's location
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "frontend" / "static"
        if candidate.exists():
            return candidate

    # Last resort: create it relative to CWD
    cwd_static.mkdir(parents=True, exist_ok=True)
    return cwd_static


def render_graph(graph) -> str | None:
    """
    Render the dependency graph to a PNG in the static folder.
    Returns the bare filename (e.g. 'dependency_graph_1234.png') so the
    frontend can load it via /static/<filename>.
    Returns None if the graph is empty or rendering fails.
    """
    if graph is None or len(graph.nodes) == 0:
        print("Graph render: empty graph, skipping.")
        return None

    try:
        STATIC_DIR = _get_static_dir()
        STATIC_DIR.mkdir(parents=True, exist_ok=True)

        print(f"Graph render: saving to {STATIC_DIR}")

        # Clean up old graphs so static/ doesn't fill up
        for old in STATIC_DIR.glob("dependency_graph_*.png"):
            try:
                old.unlink()
            except Exception:
                pass

        filename    = f"dependency_graph_{int(time.time())}.png"
        output_file = STATIC_DIR / filename

        fig, ax = plt.subplots(figsize=(14, 9))
        fig.patch.set_facecolor("#1b1f4b")
        ax.set_facecolor("#1b1f4b")

        # Layout
        if len(graph.nodes) <= 20:
            pos = nx.kamada_kawai_layout(graph)
        else:
            pos = nx.spring_layout(graph, seed=42, k=1.5)

        # Node categories
        file_nodes = [n for n in graph.nodes if n == "FILE"]
        func_nodes = [n for n in graph.nodes if n != "FILE"]

        # Draw nodes
        nx.draw_networkx_nodes(
            graph, pos,
            nodelist=file_nodes,
            node_size=3000,
            node_color="#5d7cff",
            alpha=0.95,
            ax=ax
        )
        nx.draw_networkx_nodes(
            graph, pos,
            nodelist=func_nodes,
            node_size=1800,
            node_color="#60a5fa",
            alpha=0.85,
            ax=ax
        )

        # Draw edges — MUST use RGBA tuple, NOT CSS rgba() string
        nx.draw_networkx_edges(
            graph, pos,
            edge_color=(1.0, 1.0, 1.0, 0.3),
            arrows=True,
            arrowsize=20,
            arrowstyle="-|>",
            connectionstyle="arc3,rad=0.1",
            min_source_margin=25,
            min_target_margin=25,
            ax=ax
        )

        # Labels
        nx.draw_networkx_labels(
            graph, pos,
            font_size=9,
            font_color="white",
            font_weight="bold",
            ax=ax
        )

        # Legend — MUST use RGBA tuple for edgecolor, NOT CSS rgba() string
        legend_handles = [
            mpatches.Patch(color="#5d7cff", label="File entry point"),
            mpatches.Patch(color="#60a5fa", label="Function / Import"),
        ]
        ax.legend(
            handles=legend_handles,
            loc="upper left",
            facecolor="#1b1f4b",
            edgecolor=(1.0, 1.0, 1.0, 0.2),    # tuple — NOT 'rgba(...)' string
            labelcolor="white",
            fontsize=9
        )

        ax.set_title("Dependency Graph", color="white", fontsize=14, pad=15)
        ax.axis("off")
        plt.tight_layout()
        plt.savefig(
            output_file,
            dpi=120,
            bbox_inches="tight",
            facecolor=fig.get_facecolor()
        )
        plt.close(fig)

        print(f"Graph render: saved {filename} ({output_file.stat().st_size} bytes)")
        return filename

    except Exception as e:
        import traceback
        print(f"Graph render error: {e}")
        traceback.print_exc()
        return None