from backend.utils.ollama_client import ask_ollama
import re


KNOWN_TOPICS = [
    "python", "machine learning", "federated learning", "llm",
    "react", "fastapi", "langchain", "docker", "kubernetes",
    "transformers", "deep learning", "computer vision", "rust",
    "golang", "go", "postgres", "postgresql", "redis", "mongodb",
    "terraform", "aws", "gcp", "azure", "pytorch", "tensorflow",
    "numpy", "pandas", "flask", "django", "graphql", "grpc",
    "kafka", "rabbitmq", "celery", "nginx", "linux", "git",
    "ci/cd", "devops", "mlops", "rag", "vector database",
    "embedding", "fine-tuning", "diffusion model", "gan"
]


def extract_topic(question: str) -> str:
    q = question.lower()

    # Check known topics longest-first to catch "federated learning" before "learning"
    for topic in sorted(KNOWN_TOPICS, key=len, reverse=True):
        if topic in q:
            return topic

    # Fallback: strip question words and return cleaned phrase
    cleaned = re.sub(
        r'\b(what is|what are|how does|how do|explain|tell me about|'
        r'describe|can you explain|why is|why does)\b',
        '', q, flags=re.IGNORECASE
    )
    cleaned = re.sub(r'[^a-z0-9 ]', '', cleaned).strip()
    return cleaned[:40] if cleaned else "general"


def query_tech_assistant(question: str) -> dict:
    topic = extract_topic(question)

    prompt = f"""
You are a senior computer science expert and mentor.

Explain the following concept clearly and concisely:

{question}

Structure your response as:
1. Simple explanation (2-3 sentences)
2. Real-world example
3. Where it is used in industry
4. One common misconception or gotcha to be aware of
"""

    answer = ask_ollama(prompt)

    return {
        "answer": answer,
        "topic":  topic,
    }