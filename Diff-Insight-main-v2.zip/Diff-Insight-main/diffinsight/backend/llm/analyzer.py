import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "deepseek-coder:6.7b"


REVIEWER_PROMPT = """
You are a senior software engineer performing a strict code review.

Respond ONLY in the following format:

TITLE:
CHANGE_SUMMARY:
MODIFIED_FILES:
WHAT_CHANGED:
WHY_CHANGED:
RISK_LEVEL:
IMPACT:
REVIEWER_NOTES:

Rules:
- Be concise and assertive
- Call out poor practices
- Flag missing tests, edge cases, or unclear intent
- No markdown
- No emojis
"""


JUNIOR_PROMPT = """
You are a helpful mentor explaining a git diff to a junior developer.

Respond ONLY in the following format:

TITLE:
CHANGE_SUMMARY:
WHAT_CHANGED:
WHY_CHANGED:
IMPACT:
LEARNING_NOTES:

Rules:
- Be friendly and explanatory
- Explain clearly what each file change does
- No markdown
- No emojis
"""


# -------------------------------------
# Reduce diff size so LLM runs faster
# -------------------------------------
def prepare_diff(diff_text, max_lines=120):

    lines = diff_text.splitlines()

    if len(lines) > max_lines:

        return "\n".join(lines[:max_lines]) + \
               f"\n... ({len(lines) - max_lines} more lines truncated)"

    return diff_text


# -------------------------------------
# Main analysis function
# -------------------------------------
def analyze_diff(diff_text: str, risk: str, mode: str = "reviewer") -> str:

    system_prompt = REVIEWER_PROMPT if mode == "reviewer" else JUNIOR_PROMPT

    diff_text = prepare_diff(diff_text)

    prompt = f"""
Precomputed Risk Level: {risk}

Git Diff:
{diff_text}
"""

    payload = {
        "model": MODEL,
        "prompt": system_prompt + prompt,
        "stream": False
    }

    try:

        # Increased timeout because DeepSeek takes longer
        response = requests.post(
            OLLAMA_URL,
            json=payload,
            timeout=600
        )

        response.raise_for_status()

    except requests.exceptions.Timeout:

        return """
DIFFINSIGHT REPORT
------------------
LLM ERROR

The model took too long to respond.

Possible reasons:
- First model run (cold start)
- Large diff input
- GPU/CPU load

Try again after warming the model using:
ollama run deepseek-coder:6.7b
"""

    except Exception as e:

        return f"""
DIFFINSIGHT REPORT
------------------
SYSTEM ERROR

{str(e)}
"""

    resp_json = response.json()

    detailed_report = resp_json.get("response", "")

    if not detailed_report.strip():

        detailed_report = """
LLM did not return a valid analysis.
Check the diff input or model output.
"""

    summary_intro = f"""
DIFFINSIGHT REPORT
------------------
Risk Level : {risk.upper()}

"""

    return summary_intro + detailed_report