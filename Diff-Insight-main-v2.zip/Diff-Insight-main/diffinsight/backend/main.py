from fastapi import FastAPI, Request, UploadFile, File, HTTPException, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from pathlib import Path

from unidiff import PatchSet
import re
import time
import requests as http_requests

from backend.llm.analyzer import analyze_diff
from backend.llm.tech_assistant import query_tech_assistant
from backend.services.github_service import search_repositories
from backend.utils.risk import compute_risk
from backend.utils.change_intelligence import analyse_change_intelligence
from backend.security.secret_manager import SecretManager


# ─────────────────────────────────────────────────────────────────────────────
# Startup validation
# ─────────────────────────────────────────────────────────────────────────────

def check_ollama() -> bool:
    try:
        r = http_requests.get("http://localhost:11434", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


def check_vault() -> bool:
    try:
        SecretManager.get_github_token()
        return True
    except Exception:
        return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("\n" + "="*50)
    print("  DiffInsight — Startup Check")
    print("="*50)
    ollama_ok = check_ollama()
    vault_ok  = check_vault()
    print(f"  Ollama (LLM)  : {'✓ running' if ollama_ok else '✗ NOT reachable'}")
    print(f"  Vault (token) : {'✓ connected' if vault_ok else '✗ NOT connected'}")
    print("="*50 + "\n")
    app.state.ollama_ok = ollama_ok
    app.state.vault_ok  = vault_ok
    yield


# ─────────────────────────────────────────────────────────────────────────────
# App setup
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="frontend/static"), name="static")
templates = Jinja2Templates(directory="frontend/templates")

_rate_store: dict[str, list[float]] = {}
RATE_LIMIT  = 10
RATE_WINDOW = 60
MAX_DIFF_MB = 5


def _check_rate_limit(ip: str):
    now    = time.time()
    window = _rate_store.get(ip, [])
    window = [t for t in window if now - t < RATE_WINDOW]
    if len(window) >= RATE_LIMIT:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded. Max {RATE_LIMIT} requests per {RATE_WINDOW}s."
        )
    window.append(now)
    _rate_store[ip] = window


# ─────────────────────────────────────────────────────────────────────────────
# Homepage
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ─────────────────────────────────────────────────────────────────────────────
# Radar scoring helpers
# ─────────────────────────────────────────────────────────────────────────────

def _score_security(added_lines: list[str], removed_lines: list[str]) -> int:
    SECURITY_KEYWORDS = [
        "password", "passwd", "token", "secret", "api_key", "apikey",
        "auth", "jwt", "oauth", "encrypt", "decrypt", "hash", "salt",
        "credentials", "private_key", "access_key", "signature"
    ]
    HARDCODED_PATTERN = re.compile(
        r'(password|token|secret|api_key|apikey)\s*=\s*["\'][^"\']{4,}["\']',
        re.IGNORECASE
    )
    SECURITY_IMPORTS = re.compile(
        r'import.*(jwt|crypto|bcrypt|hashlib|hmac|ssl|cryptography|passlib)',
        re.IGNORECASE
    )
    score = 0
    for line in added_lines:
        l = line.lower()
        if any(k in l for k in SECURITY_KEYWORDS): score += 2
        if HARDCODED_PATTERN.search(line):          score += 3
        if SECURITY_IMPORTS.search(line):           score += 1
    for line in removed_lines:
        if any(k in line.lower() for k in SECURITY_KEYWORDS): score += 1
    return min(10, score)


def _score_performance(added_lines: list[str], removed_lines: list[str]) -> int:
    LOOP_PATTERN  = re.compile(r'^\s*(for |while )')
    QUERY_PATTERN = re.compile(r'(SELECT|\.query\(|\.filter\(|\.find\(|db\.)', re.IGNORECASE)
    CACHE_PATTERN = re.compile(r'(cache|redis|memcache|lru_cache|@cache)', re.IGNORECASE)
    ASYNC_PATTERN = re.compile(r'\b(async def|await )\b')
    HEAVY_PATTERN = re.compile(r'\.(sort|groupby|merge|join|aggregate)\(', re.IGNORECASE)

    score       = 0
    inside_loop = False
    for line in added_lines:
        if LOOP_PATTERN.match(line):
            inside_loop = True
            score += 1
        if inside_loop and QUERY_PATTERN.search(line): score += 3
        if QUERY_PATTERN.search(line) and not inside_loop: score += 1
        if CACHE_PATTERN.search(line): score -= 2
        if ASYNC_PATTERN.search(line): score -= 1
        if HEAVY_PATTERN.search(line): score += 1
        if inside_loop and line.strip() == '': inside_loop = False
    return min(10, max(0, score))


def _score_complexity(
    added_lines: list[str], removed_lines: list[str],
    functions_changed: int, files_changed: int
) -> int:
    BRANCH_PATTERN = re.compile(r'^\s*(if |elif |else:|except|except |case )')
    LOOP_PATTERN   = re.compile(r'^\s*(for |while )')
    DEF_PATTERN    = re.compile(r'^\s*(def |class |async def )')
    LAMBDA_PATTERN = re.compile(r'\blambda\b|(\[.+for.+in.+\])|(\{.+for.+in.+\})')
    DEEP_INDENT    = re.compile(r'^\s{16,}')

    score = 0
    for line in added_lines:
        if DEF_PATTERN.match(line):     score += 1
        if BRANCH_PATTERN.match(line):  score += 1
        if LOOP_PATTERN.match(line):    score += 1
        if LAMBDA_PATTERN.search(line): score += 1
        if DEEP_INDENT.match(line):     score += 1
    score += max(0, (len(added_lines) - len(removed_lines)) // 15)
    return min(10, max(0, score))


def _score_stability(
    added_lines: list[str], removed_lines: list[str],
    files_changed: int, patch: PatchSet
) -> int:
    CONFIG_PATTERN    = re.compile(r'\.(env|yaml|yml|toml|ini|cfg|conf|json)$', re.IGNORECASE)
    MIGRATION_PATTERN = re.compile(r'(migration|migrate|alembic|schema)', re.IGNORECASE)
    ROUTE_PATTERN     = re.compile(r'(@app\.(get|post|put|delete|patch)|router\.|@router)', re.IGNORECASE)

    score = min(3, files_changed)
    for patched_file in patch:
        fname = patched_file.path or ""
        if CONFIG_PATTERN.search(fname):    score += 2
        if MIGRATION_PATTERN.search(fname): score += 2
    total = len(added_lines) + len(removed_lines)
    if total > 0:
        score += int((len(removed_lines) / total) * 3)
    for line in added_lines + removed_lines:
        if ROUTE_PATTERN.search(line): score += 1
    if len(removed_lines) == 0 and len(added_lines) > 0:
        score -= 2
    return min(10, max(0, score))


def _score_testing(
    added_lines: list[str], removed_lines: list[str],
    all_lines: list[str], patch: PatchSet
) -> int:
    TEST_FILE_PATTERN = re.compile(r'(test_|_test\.py|spec\.py|tests/)', re.IGNORECASE)
    ASSERT_PATTERN    = re.compile(r'\bassert\b|assertEqual|assertTrue|assertFalse|assertRaises', re.IGNORECASE)
    MOCK_PATTERN      = re.compile(r'\b(mock|patch|fixture|MagicMock|mocker)\b', re.IGNORECASE)
    TEST_DEF_PATTERN  = re.compile(r'def test_')

    score = 0
    assert_count = mock_count = test_def_count = test_line_count = 0

    for patched_file in patch:
        if TEST_FILE_PATTERN.search(patched_file.path or ""):
            score += 3

    for line in added_lines:
        if ASSERT_PATTERN.search(line):   assert_count   += 1; test_line_count += 1
        if MOCK_PATTERN.search(line):     mock_count     += 1; test_line_count += 1
        if TEST_DEF_PATTERN.search(line): test_def_count += 1; test_line_count += 1

    score += min(3, assert_count)
    score += min(2, mock_count)
    score += min(3, test_def_count)
    if len(added_lines) > 10 and test_line_count == 0: score -= 3
    if len(added_lines) > 0:
        score += int((test_line_count / len(added_lines)) * 3)
    return min(10, max(0, score))


# ─────────────────────────────────────────────────────────────────────────────
# Diff normaliser + parser
# ─────────────────────────────────────────────────────────────────────────────

def _normalise_diff(diff_text: str) -> str:
    normalised_lines = []
    for line in diff_text.splitlines():
        if line.startswith('Binary files') and 'differ' in line:
            continue
        if line.startswith('--- ') and '\t' in line:
            path = re.sub(r'^[^/]+/', '', line[4:].split('\t')[0].strip())
            normalised_lines.append(f'--- a/{path}')
            continue
        if line.startswith('+++ ') and '\t' in line:
            path = re.sub(r'^[^/]+/', '', line[4:].split('\t')[0].strip())
            normalised_lines.append(f'+++ b/{path}')
            continue
        if line.startswith('diff -') and not line.startswith('diff --git'):
            parts = line.split()
            if len(parts) >= 3:
                path = re.sub(r'^[^/]+/', '', parts[-1])
                normalised_lines.append(f'diff --git a/{path} b/{path}')
                continue
        normalised_lines.append(line)
    return '\n'.join(normalised_lines)


def analyze_diff_content(diff_text: str) -> dict:
    if not diff_text or not diff_text.strip():
        raise ValueError("Diff text is empty.")

    normalised = _normalise_diff(diff_text)

    try:
        patch = PatchSet(normalised)
    except Exception as e:
        raise ValueError(f"Could not parse diff: {e}")

    files_changed     = len(patch)
    functions_changed = 0
    added_lines       = []
    removed_lines     = []
    FUNC_PATTERN      = re.compile(r'(def |function |class |async def )')

    for patched_file in patch:
        for hunk in patched_file:
            for line in hunk:
                text = line.value.rstrip('\n')
                if line.is_added:
                    added_lines.append(text)
                    if FUNC_PATTERN.search(text): functions_changed += 1
                elif line.is_removed:
                    removed_lines.append(text)

    radar = {
        "security":    _score_security(added_lines, removed_lines),
        "performance": _score_performance(added_lines, removed_lines),
        "complexity":  _score_complexity(added_lines, removed_lines, functions_changed, files_changed),
        "stability":   _score_stability(added_lines, removed_lines, files_changed, patch),
        "testing":     _score_testing(added_lines, removed_lines, added_lines + removed_lines, patch),
    }

    return {
        "files_changed":     files_changed,
        "lines_added":       len(added_lines),
        "lines_removed":     len(removed_lines),
        "functions_changed": functions_changed,
        "radar":             radar,
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /analyze
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/analyze")
async def analyze_diff_endpoint(
    request: Request,
    file: UploadFile = File(None),
    mode: str = Form("reviewer")
):
    _check_rate_limit(request.client.host)

    diff_text  = ""
    final_mode = "reviewer"

    if file and file.filename:
        suffix = Path(file.filename).suffix.lower()
        if suffix not in {".diff", ".patch", ".txt"}:
            raise HTTPException(status_code=400, detail=f"Invalid file type '{suffix}'.")
        raw = await file.read()
        if len(raw) > MAX_DIFF_MB * 1024 * 1024:
            raise HTTPException(status_code=400, detail=f"File too large. Max {MAX_DIFF_MB}MB.")
        diff_text  = raw.decode("utf-8", errors="replace")
        final_mode = mode if mode in {"reviewer", "junior"} else "reviewer"
    else:
        try:
            body       = await request.json()
            diff_text  = body.get("diff", "")
            final_mode = body.get("mode", "reviewer")
            if final_mode not in {"reviewer", "junior"}: final_mode = "reviewer"
        except Exception:
            pass

    if not diff_text or not diff_text.strip():
        raise HTTPException(status_code=400, detail="No diff content provided.")

    try:
        metrics = analyze_diff_content(diff_text)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    risk = compute_risk(diff_text)

    if not app.state.ollama_ok:
        report = (
            "⚠️  Ollama is not running.\n\n"
            "Start it with:\n  ollama serve\n\n"
            "Then warm the model:\n  ollama run deepseek-coder:6.7b"
        )
    else:
        report = analyze_diff(diff_text, risk=risk, mode=final_mode)

    intelligence = analyse_change_intelligence(diff_text)

    return {
        "report":       report,
        "mode":         final_mode,
        "risk_level":   risk,
        "stats": {
            "files":     metrics["files_changed"],
            "added":     metrics["lines_added"],
            "removed":   metrics["lines_removed"],
            "functions": metrics["functions_changed"],
        },
        "risk":         list(metrics["radar"].values()),
        "radar":        metrics["radar"],
        "intelligence": intelligence,
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /ask
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/ask")
async def ask_tech_assistant(request: Request, data: dict):
    _check_rate_limit(request.client.host)
    question = data.get("question", "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question is required.")
    if not app.state.ollama_ok:
        raise HTTPException(status_code=503, detail="Ollama not running.")
    return query_tech_assistant(question)


# ─────────────────────────────────────────────────────────────────────────────
# GET /repos/{topic}
# ─────────────────────────────────────────────────────────────────────────────

VALID_SORT_OPTIONS = {"stars", "forks", "updated", "issues", "watchers"}

@app.get("/repos/{topic}")
async def github_repos(request: Request, topic: str, sort: str = "stars", language: str = None):
    _check_rate_limit(request.client.host)
    if sort not in VALID_SORT_OPTIONS:
        raise HTTPException(status_code=400, detail=f"Invalid sort '{sort}'.")
    if not app.state.vault_ok:
        raise HTTPException(status_code=503, detail="Vault not connected.")
    try:
        return search_repositories(query=topic, sort=sort, language=language or None)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"GitHub API error: {exc}")


@app.get("/repos")
async def github_repos_empty():
    return []


@app.get("/health")
async def health():
    return {"ollama": app.state.ollama_ok, "vault": app.state.vault_ok}