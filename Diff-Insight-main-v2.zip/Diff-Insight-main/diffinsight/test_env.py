import os
from backend.security.secret_manager import SecretManager

print("VAULT_ADDR:", os.getenv("VAULT_ADDR"))
print("VAULT_TOKEN:", os.getenv("VAULT_TOKEN"))

github_token = SecretManager.get_github_token()

print("GITHUB_TOKEN:", github_token)