// ── HEALTH CHECK ──────────────────────────────────────────────────────────────

async function checkHealth() {
  try {
    const res  = await fetch('/health')
    const data = await res.json()
    const dot  = (id, ok) => {
      const el = document.getElementById(id)
      if (!el) return
      el.classList.add(ok ? 'dot-ok' : 'dot-err')
      el.title = el.title + (ok ? ' — OK' : ' — NOT AVAILABLE')
    }
    dot('dotOllama', data.ollama)
    dot('dotVault',  data.vault)
  } catch (_) {}
}

checkHealth()


// ── RADAR CHART ───────────────────────────────────────────────────────────────

let chart

function initChart() {
  const ctx = document.getElementById('riskChart')
  chart = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Security', 'Performance', 'Complexity', 'Stability', 'Testing'],
      datasets: [{
        label: 'Risk Profile',
        data: [0, 0, 0, 0, 0],
        borderColor: '#8fa6ff',
        backgroundColor: 'rgba(143,166,255,0.2)',
        borderWidth: 2,
        pointBackgroundColor: '#8fa6ff',
        pointRadius: 4,
      }]
    },
    options: {
      animation: { duration: 600 },
      plugins: {
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const descriptions = [
                'Security: sensitive code exposure (0=safe, 10=critical)',
                'Performance: N+1/loop risk (0=fast, 10=slow)',
                'Complexity: cognitive load (0=simple, 10=complex)',
                'Stability: churn/config risk (0=stable, 10=risky)',
                'Testing: coverage signal (0=untested, 10=well tested)',
              ]
              return `${descriptions[ctx.dataIndex]} — Score: ${ctx.raw}`
            }
          }
        },
        legend: { display: false }
      },
      scales: {
        r: {
          grid:         { color: 'rgba(255,255,255,0.15)' },
          pointLabels:  { color: '#fff', font: { size: 13 } },
          ticks:        { display: false },
          suggestedMin: 0,
          suggestedMax: 10,
          angleLines:   { color: 'rgba(255,255,255,0.1)' },
        }
      }
    }
  })
}

initChart()


// ── NAVIGATION ────────────────────────────────────────────────────────────────

function activate(section) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'))
  document.querySelectorAll('.nav-item').forEach(p => p.classList.remove('active'))
  document.getElementById(section + '-section').classList.add('active')
  document.getElementById('nav-' + section).classList.add('active')
}

document.getElementById('nav-diff').onclick      = () => activate('diff')
document.getElementById('nav-assistant').onclick = () => activate('assistant')
document.getElementById('nav-github').onclick    = () => activate('github')


// ── INPUT TOGGLE ──────────────────────────────────────────────────────────────

function switchInput(mode) {
  const fileEl   = document.getElementById('inputFile')
  const pasteEl  = document.getElementById('inputPaste')
  const btnFile  = document.getElementById('toggleFile')
  const btnPaste = document.getElementById('togglePaste')
  if (mode === 'file') {
    fileEl.style.display  = 'flex'
    pasteEl.style.display = 'none'
    btnFile.classList.add('active')
    btnPaste.classList.remove('active')
  } else {
    fileEl.style.display  = 'none'
    pasteEl.style.display = 'flex'
    btnPaste.classList.add('active')
    btnFile.classList.remove('active')
  }
}


// ── LOADING TIMER ─────────────────────────────────────────────────────────────

function startTimer(labelId, prefix) {
  const start = Date.now()
  const el    = document.getElementById(labelId)
  if (el) el.textContent = `${prefix} 0s`
  return setInterval(() => {
    if (el) el.textContent = `${prefix} ${((Date.now() - start) / 1000).toFixed(0)}s`
  }, 500)
}


// ── CHANGE INTELLIGENCE RENDERER ─────────────────────────────────────────────

const LAYER_ICONS = {
  'LLM / AI':        '🤖',
  'Security':        '🔒',
  'Services':        '🔌',
  'Utilities':       '🔧',
  'Backend':         '⚙️',
  'Frontend JS/CSS': '🎨',
  'Frontend HTML':   '🖼️',
  'Frontend':        '💻',
  'Tests':           '🧪',
  'Config / Infra':  '📦',
  'Database':        '🗄️',
  'Docs':            '📄',
  'Other':           '📁',
}

const CHANGE_TYPE_STYLE = {
  'new':        { label: 'NEW',        color: '#4ade80' },
  'deleted':    { label: 'DELETED',    color: '#f87171' },
  'refactored': { label: 'REFACTORED', color: '#fb923c' },
  'expanded':   { label: 'EXPANDED',   color: '#60a5fa' },
  'modified':   { label: 'MODIFIED',   color: '#a78bfa' },
}

const RISK_STYLE = {
  'High':   { color: '#f87171', bg: 'rgba(248,113,113,0.12)' },
  'Medium': { color: '#fb923c', bg: 'rgba(251,146,60,0.12)'  },
  'Low':    { color: '#4ade80', bg: 'rgba(74,222,128,0.10)'  },
}

const OVERALL_TYPE_LABEL = {
  'additive':    { icon: '➕', label: 'Additive',     color: '#4ade80' },
  'refactor':    { icon: '♻️', label: 'Refactor',     color: '#fb923c' },
  'mixed':       { icon: '🔀', label: 'Mixed',         color: '#60a5fa' },
  'destructive': { icon: '🗑️', label: 'Destructive',  color: '#f87171' },
  'unknown':     { icon: '❓', label: 'Unknown',       color: '#9ca3af' },
}

function renderIntelligence(intel) {
  const container = document.getElementById('intelligencePanel')
  if (!intel || !intel.file_changes || intel.file_changes.length === 0) {
    container.innerHTML = `
      <div class="intel-empty">
        <span style="font-size:32px;opacity:0.4">📂</span>
        <p>No file changes detected in this diff.</p>
      </div>`
    return
  }

  const ot     = OVERALL_TYPE_LABEL[intel.overall_type] || OVERALL_TYPE_LABEL['unknown']
  const layers = Object.entries(intel.layer_summary)
  const exts   = Object.entries(intel.ext_breakdown)

  // Summary bar
  let html = `
    <div class="intel-summary-bar">
      <span class="intel-type-badge" style="background:${ot.color}22; color:${ot.color}">
        ${ot.icon} ${ot.label}
      </span>
      <span class="intel-summary-text">${intel.summary_line}</span>
    </div>`

  // Layers
  html += `<div class="intel-section-title">Layers Touched</div><div class="intel-layers">`
  for (const [layer, count] of layers) {
    const icon = LAYER_ICONS[layer] || '📁'
    html += `
      <div class="intel-layer-chip">
        <span>${icon} ${layer}</span>
        <span class="intel-chip-count">${count} file${count !== 1 ? 's' : ''}</span>
      </div>`
  }
  html += `</div>`

  // Merge conflict candidates
  if (intel.at_risk_files && intel.at_risk_files.length > 0) {
    html += `<div class="intel-section-title">⚠️ Merge Conflict Candidates</div><div class="intel-risk-list">`
    for (const f of intel.at_risk_files) {
      const rs = RISK_STYLE[f.conflict_risk]
      html += `
        <div class="intel-risk-item" style="border-left-color:${rs.color}; background:${rs.bg}">
          <span class="intel-risk-path">${f.path}</span>
          <span class="intel-risk-badge" style="color:${rs.color}">${f.conflict_risk} risk</span>
          <span class="intel-risk-churn">+${f.added} / -${f.removed}</span>
        </div>`
    }
    html += `</div>`
  }

  // Per-file breakdown
  html += `<div class="intel-section-title">File Breakdown</div><div class="intel-file-list">`
  for (const f of intel.file_changes) {
    const ct  = CHANGE_TYPE_STYLE[f.change_type] || CHANGE_TYPE_STYLE['modified']
    const rs  = RISK_STYLE[f.conflict_risk]
    const bar = Math.min(100, Math.round((f.churn / (intel.total_churn || 1)) * 100))
    html += `
      <div class="intel-file-card">
        <div class="intel-file-header">
          <span class="intel-file-type-badge" style="color:${ct.color}">${ct.label}</span>
          <span class="intel-file-path">${f.path}</span>
          <span class="intel-file-layer">${LAYER_ICONS[f.layer] || ''} ${f.layer}</span>
        </div>
        <div class="intel-file-meta">
          <span class="intel-added">+${f.added}</span>
          <span class="intel-removed">-${f.removed}</span>
          <span class="intel-conflict" style="color:${rs.color}">${f.conflict_risk} conflict risk</span>
        </div>
        <div class="intel-churn-bar-bg">
          <div class="intel-churn-bar-fill" style="width:${bar}%"></div>
        </div>
      </div>`
  }
  html += `</div>`

  // Extensions
  if (exts.length > 0) {
    html += `<div class="intel-section-title">File Types</div><div class="intel-ext-row">`
    for (const [ext, count] of exts) {
      html += `<div class="intel-ext-chip">.${ext} <strong>${count}</strong></div>`
    }
    html += `</div>`
  }

  container.innerHTML = html
}


// ── DIFF ANALYSIS ─────────────────────────────────────────────────────────────

document.getElementById('analyzeBtn').onclick = async () => {
  const reportEl  = document.getElementById('diffReport')
  const statsEl   = document.getElementById('stats')
  const loadingEl = document.getElementById('loadingReport')
  const modeTagEl = document.getElementById('modeTag')
  const modeVal   = document.getElementById('analyzeMode').value
  const isPaste   = document.getElementById('togglePaste').classList.contains('active')

  let fetchOpts = {}

  if (isPaste) {
    const text = document.getElementById('diffPaste').value.trim()
    if (!text) { alert('Please paste a diff first'); return }
    fetchOpts = {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ diff: text, mode: modeVal }),
    }
  } else {
    const file = document.getElementById('diffFile').files[0]
    if (!file) { alert('Please upload a .diff file'); return }
    const formData = new FormData()
    formData.append('file', file)
    formData.append('mode', modeVal)
    fetchOpts = { method: 'POST', body: formData }
  }

  reportEl.style.display  = 'none'
  loadingEl.style.display = 'flex'
  reportEl.classList.remove('error-text')
  document.getElementById('intelligencePanel').innerHTML =
    '<div class="intel-empty"><div class="spinner"></div><p>Analysing changes…</p></div>'

  const timer = startTimer('loadingTimer', 'Analyzing…')

  try {
    const res  = await fetch('/analyze', fetchOpts)
    const data = await res.json()

    clearInterval(timer)
    loadingEl.style.display = 'none'
    reportEl.style.display  = 'block'

    if (!res.ok) {
      reportEl.textContent = `❌ Error: ${data.detail || res.statusText}`
      reportEl.classList.add('error-text')
      return
    }

    reportEl.textContent = data.report

    modeTagEl.textContent = data.mode === 'junior' ? '🎓 Junior Mentor' : '👔 Senior Reviewer'
    modeTagEl.className   = 'mode-tag mode-' + data.mode

    statsEl.textContent =
      `Files Changed:      ${data.stats.files}\n` +
      `Lines Added:        ${data.stats.added}\n` +
      `Lines Removed:      ${data.stats.removed}\n` +
      `Functions Modified: ${data.stats.functions}\n` +
      `Risk Level:         ${data.risk_level}`

    chart.data.datasets[0].data = data.risk
    chart.update()

    renderIntelligence(data.intelligence)

  } catch (err) {
    clearInterval(timer)
    loadingEl.style.display = 'none'
    reportEl.style.display  = 'block'
    reportEl.textContent    = `❌ Request failed: ${err.message}`
    reportEl.classList.add('error-text')
  }
}


// ── TECH ASSISTANT ────────────────────────────────────────────────────────────

document.getElementById('askBtn').onclick = async () => {
  const question  = document.getElementById('questionInput').value.trim()
  if (!question)  { alert('Please enter a question'); return }

  const answerEl  = document.getElementById('assistantAnswer')
  const cardEl    = document.getElementById('assistantCard')
  const loadingEl = document.getElementById('loadingAssistant')
  const topicEl   = document.getElementById('detectedTopic')

  cardEl.style.display    = 'block'
  answerEl.style.display  = 'none'
  loadingEl.style.display = 'flex'
  topicEl.textContent     = ''
  answerEl.classList.remove('error-text')

  const timer = startTimer('loadingTimerAssistant', 'Thinking…')

  try {
    const res  = await fetch('/ask', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ question }),
    })
    const data = await res.json()

    clearInterval(timer)
    loadingEl.style.display = 'none'
    answerEl.style.display  = 'block'

    if (!res.ok) {
      answerEl.textContent = `❌ Error: ${data.detail || res.statusText}`
      answerEl.classList.add('error-text')
      return
    }

    answerEl.textContent = data.answer
    topicEl.textContent  = `Detected topic: ${data.topic}`

  } catch (err) {
    clearInterval(timer)
    loadingEl.style.display = 'none'
    answerEl.style.display  = 'block'
    answerEl.textContent    = `❌ Request failed: ${err.message}`
    answerEl.classList.add('error-text')
  }
}


// ── GITHUB EXPLORER ───────────────────────────────────────────────────────────

document.getElementById('searchRepoBtn').onclick = () => {
  const topic    = document.getElementById('repoTopic').value.trim()
  const sort     = document.getElementById('repoSort').value || 'stars'
  const language = document.getElementById('repoLanguage').value.trim()
  if (!topic) { alert('Enter a search topic'); return }
  loadRepos(topic, sort, language)
}

async function loadRepos(topic, sort = 'stars', language = '') {
  const container = document.getElementById('repoResults')
  container.innerHTML = '<p class="loading-text">Searching GitHub…</p>'

  const url = `/repos/${encodeURIComponent(topic)}?sort=${sort}` +
              (language ? `&language=${encodeURIComponent(language)}` : '')

  try {
    const res  = await fetch(url)
    const data = await res.json()

    if (!res.ok) {
      container.innerHTML = `<div class="error-card">❌ ${data.detail || res.statusText}</div>`
      return
    }

    container.innerHTML = ''
    if (!data.length) {
      container.innerHTML = '<p class="loading-text">No repositories found.</p>'
      return
    }

    data.forEach((repo, index) => {
      const div = document.createElement('div')
      div.className = 'repo-card'
      div.innerHTML = `
        <div class="repo-header">
          <span class="repo-rank">#${index + 1}</span>
          <strong>${repo.name}</strong>
          <span class="repo-lang">${repo.language}</span>
        </div>
        <p>${repo.description}</p>
        <div class="repo-meta">
          <span>⭐ ${repo.stars.toLocaleString()}</span>
          <span>🍴 ${repo.forks.toLocaleString()}</span>
          <span>🐛 ${repo.issues.toLocaleString()} issues</span>
          <span>👁️ ${repo.watchers.toLocaleString()} watchers</span>
          <span>🕒 ${new Date(repo.updated).toLocaleDateString()}</span>
        </div>
        <a href="${repo.url}" target="_blank">Open Repo →</a>
      `
      container.appendChild(div)
    })

  } catch (err) {
    container.innerHTML = `<div class="error-card">❌ Request failed: ${err.message}</div>`
  }
}