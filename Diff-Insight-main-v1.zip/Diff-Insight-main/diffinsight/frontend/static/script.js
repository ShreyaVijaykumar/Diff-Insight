let chart

function initChart() {
  const ctx = document.getElementById('riskChart')
  chart = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Security', 'Performance', 'Complexity', 'Stability', 'Testing'],
      datasets: [{
        label: 'Risk Profile',
        data: [3, 6, 7, 7, 4],
        borderColor: '#8fa6ff',
        backgroundColor: 'rgba(143,166,255,0.2)',
        borderWidth: 2
      }]
    },
    options: {
      scales: {
        r: {
          grid: { color: 'rgba(255,255,255,0.15)' },
          pointLabels: { color: '#fff' },
          ticks: { display: false },
          suggestedMin: 0,
          suggestedMax: 10
        }
      }
    }
  })
}

initChart()


// ── NAVIGATION ────────────────────────────────────────────────────────────────

const navDiff      = document.getElementById('nav-diff')
const navAssistant = document.getElementById('nav-assistant')
const navGithub    = document.getElementById('nav-github')

const diffSection      = document.getElementById('diff-section')
const assistantSection = document.getElementById('assistant-section')
const githubSection    = document.getElementById('github-section')

function activate(section) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'))
  document.querySelectorAll('.nav-item').forEach(p => p.classList.remove('active'))

  if (section === 'diff')      { diffSection.classList.add('active');      navDiff.classList.add('active') }
  if (section === 'assistant') { assistantSection.classList.add('active'); navAssistant.classList.add('active') }
  if (section === 'github')    { githubSection.classList.add('active');    navGithub.classList.add('active') }
}

navDiff.onclick      = () => activate('diff')
navAssistant.onclick = () => activate('assistant')
navGithub.onclick    = () => activate('github')


// ── DIFF ANALYSIS ─────────────────────────────────────────────────────────────

document.getElementById('analyzeBtn').onclick = async () => {
  const file = document.getElementById('diffFile').files[0]
  if (!file) { alert('Please upload a .diff file'); return }

  const reportEl = document.getElementById('diffReport')
  const statsEl  = document.getElementById('stats')
  reportEl.textContent = 'Analyzing…'

  const formData = new FormData()
  formData.append('file', file)

  try {
    const res  = await fetch('/analyze', { method: 'POST', body: formData })
    const data = await res.json()

    if (!res.ok) {
      reportEl.textContent = `Error: ${data.detail || res.statusText}`
      return
    }

    reportEl.textContent = data.report

    statsEl.textContent =
      `Files Changed:      ${data.stats.files}\n` +
      `Lines Added:        ${data.stats.added}\n` +
      `Lines Removed:      ${data.stats.removed}\n` +
      `Functions Modified: ${data.stats.functions}`

    chart.data.datasets[0].data = data.risk
    chart.update()

  } catch (err) {
    reportEl.textContent = `Request failed: ${err.message}`
  }
}


// ── TECH ASSISTANT ────────────────────────────────────────────────────────────

document.getElementById('askBtn').onclick = async () => {
  const question = document.getElementById('questionInput').value.trim()
  if (!question) { alert('Please enter a question'); return }

  const answerEl = document.getElementById('assistantAnswer')
  answerEl.textContent = 'Thinking…'

  try {
    const res  = await fetch('/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question })
    })
    const data = await res.json()

    if (!res.ok) {
      answerEl.textContent = `Error: ${data.detail || res.statusText}`
      return
    }

    answerEl.textContent = data.answer

    const topicEl = document.getElementById('detectedTopic')
    if (topicEl) topicEl.textContent = `Detected topic: ${data.topic}`

  } catch (err) {
    answerEl.textContent = `Request failed: ${err.message}`
  }
}


// ── GITHUB EXPLORER ───────────────────────────────────────────────────────────

document.getElementById('searchRepoBtn').onclick = () => {
  const topic    = document.getElementById('repoTopic').value.trim()
  const sort     = document.getElementById('repoSort').value || 'stars'
  const language = document.getElementById('repoLanguage').value.trim()
  if (!topic) { alert('Enter a search topic'); return }
  loadRepos(topic, sort, language)
}

async function loadRepos(topic, sort = 'stars', language = '') {
  const container = document.getElementById('repoResults')
  container.innerHTML = '<p>Searching…</p>'

  const url = `/repos/${encodeURIComponent(topic)}?sort=${sort}` +
              (language ? `&language=${encodeURIComponent(language)}` : '')

  try {
    const res  = await fetch(url)
    const data = await res.json()

    if (!res.ok) {
      container.innerHTML = `<p>Error: ${data.detail || res.statusText}</p>`
      return
    }

    container.innerHTML = ''

    if (!data.length) {
      container.innerHTML = '<p>No repositories found.</p>'
      return
    }

    data.forEach((repo, index) => {
      const div = document.createElement('div')
      div.className = 'repo-card'
      div.innerHTML = `
        <div class="repo-header">
          <span class="repo-rank">#${index + 1}</span>
          <strong>${repo.name}</strong>
          <span class="repo-lang">${repo.language}</span>
        </div>
        <p>${repo.description}</p>
        <div class="repo-meta">
          <span>⭐ ${repo.stars.toLocaleString()}</span>
          <span>🍴 ${repo.forks.toLocaleString()}</span>
          <span>🐛 ${repo.issues.toLocaleString()} issues</span>
          <span>👁️ ${repo.watchers.toLocaleString()} watchers</span>
          <span>🕒 ${new Date(repo.updated).toLocaleDateString()}</span>
        </div>
        <a href="${repo.url}" target="_blank">Open Repo →</a>
      `
      container.appendChild(div)
    })

  } catch (err) {
    container.innerHTML = `<p>Request failed: ${err.message}</p>`
  }
}