from backend.utils.ollama_client import ask_ollama


def query_tech_assistant(question):

    topic = extract_topic(question)

    prompt = f"""
You are a senior computer science expert.

Explain the following concept clearly and concisely:

{question}

Provide:
- a simple explanation
- a real-world example
- where it is used in industry
"""

    answer = ask_ollama(prompt)

    return {
        "answer": answer,
        "topic": topic
    }


def extract_topic(question):

    keywords = [
        "python",
        "machine learning",
        "federated learning",
        "llm",
        "react",
        "fastapi",
        "langchain",
        "docker",
        "kubernetes",
        "transformers",
        "deep learning",
        "computer vision"
    ]

    question = question.lower()

    for k in keywords:
        if k in question:
            return k

    # fallback: clean question
    words = question.replace("what is", "").replace("?", "")
    return words.strip()