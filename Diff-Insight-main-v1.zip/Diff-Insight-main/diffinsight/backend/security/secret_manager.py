import os
import hvac


class SecretManager:

    _client = None

    @classmethod
    def _get_client(cls):
        """
        Create or return an authenticated Vault client
        """

        if cls._client is None:

            vault_url = os.getenv("VAULT_ADDR")
            vault_token = os.getenv("VAULT_TOKEN")

            if not vault_url or not vault_token:
                raise RuntimeError("Vault credentials missing. Set VAULT_ADDR and VAULT_TOKEN.")

            cls._client = hvac.Client(
                url=vault_url,
                token=vault_token
            )

            # verify authentication
            if not cls._client.is_authenticated():
                raise RuntimeError("Vault authentication failed. Invalid VAULT_TOKEN.")

        return cls._client


    @classmethod
    def get_github_token(cls):
        """
        Retrieve GitHub token from Vault.
        Falls back to environment variable if Vault fails.
        """

        try:

            client = cls._get_client()

            secret = client.secrets.kv.v2.read_secret_version(
                path="github",
                mount_point="secret"
            )

            return secret["data"]["data"]["token"]

        except Exception as e:

            print("Vault error:", e)

            # fallback to environment variable
            fallback = os.getenv("GITHUB_TOKEN")

            if fallback:
                print("Using fallback GitHub token from environment.")
                return fallback

            raise RuntimeError(
                "Failed to retrieve GitHub token from Vault and no fallback token found."
            )