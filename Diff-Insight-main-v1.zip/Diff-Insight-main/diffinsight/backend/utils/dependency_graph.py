import ast
import networkx as nx


def extract_code_from_diff(diff_text):

    code_lines = []

    for line in diff_text.splitlines():

        if line.startswith("+++") or line.startswith("---"):
            continue

        if line.startswith("-"):
            continue

        if line.startswith("+"):
            code_lines.append(line[1:])
        else:
            code_lines.append(line)

    return "\n".join(code_lines)


def build_dependency_graph_from_diff(diff_text):

    code = extract_code_from_diff(diff_text)

    graph = nx.DiGraph()

    try:
        tree = ast.parse(code)
    except Exception:
        return graph

    current_function = None

    for node in ast.walk(tree):

        if isinstance(node, ast.Import):

            for alias in node.names:
                graph.add_edge("FILE", alias.name)

        elif isinstance(node, ast.ImportFrom):

            if node.module:
                graph.add_edge("FILE", node.module)

        elif isinstance(node, ast.FunctionDef):

            current_function = node.name
            graph.add_edge("FILE", current_function)

        elif isinstance(node, ast.Call):

            if isinstance(node.func, ast.Name):

                called = node.func.id

                if current_function:
                    graph.add_edge(current_function, called)
                else:
                    graph.add_edge("FILE", called)

            elif isinstance(node.func, ast.Attribute):

                called = node.func.attr

                if current_function:
                    graph.add_edge(current_function, called)
                else:
                    graph.add_edge("FILE", called)

    return graph