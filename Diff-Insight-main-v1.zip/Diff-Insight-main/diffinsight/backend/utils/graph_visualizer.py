from pathlib import Path
import matplotlib.pyplot as plt
import networkx as nx
import time

BASE_DIR = Path(__file__).resolve().parent.parent.parent
STATIC_DIR = BASE_DIR / "frontend" / "static"


def render_graph(graph):

    if len(graph.nodes) == 0:
        return None

    STATIC_DIR.mkdir(exist_ok=True)

    filename = f"dependency_graph_{int(time.time())}.png"
    output_file = STATIC_DIR / filename

    plt.figure(figsize=(12, 8))

    # Better layout for clarity
    pos = nx.spring_layout(graph, seed=42, k=1)

    nx.draw_networkx_nodes(graph, pos, node_size=2000, node_color="#60a5fa")
    nx.draw_networkx_edges(graph, pos, arrows=True)
    nx.draw_networkx_labels(graph, pos, font_size=10, font_weight="bold")

    plt.title("Dependency Graph")
    plt.axis("off")

    plt.tight_layout()
    plt.savefig(output_file)
    plt.close()

    return filename