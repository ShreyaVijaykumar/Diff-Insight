from fastapi import FastAPI, Request, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from unidiff import PatchSet
import re

from backend.llm.analyzer import analyze_diff
from backend.llm.tech_assistant import query_tech_assistant
from backend.services.github_service import search_repositories
from backend.utils.risk import compute_risk

app = FastAPI()

app.mount("/static", StaticFiles(directory="frontend/static"), name="static")
templates = Jinja2Templates(directory="frontend/templates")


# ─────────────────────────────────────────────────────────────────────────────
# Homepage
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ─────────────────────────────────────────────────────────────────────────────
# Radar scoring helpers
# ─────────────────────────────────────────────────────────────────────────────

def _score_security(added_lines: list[str], removed_lines: list[str]) -> int:
    """
    Scores 0-10 based on:
    - Added lines that touch auth/crypto/secrets  (+2 each, high risk = new exposure)
    - Removed lines that touch auth/crypto/secrets (+1 each, removal could break protection)
    - Hardcoded secrets pattern in added lines     (+3 each, critical)
    - Security imports being added                 (+1 each)

    Capped at 10.
    """
    SECURITY_KEYWORDS = [
        "password", "passwd", "token", "secret", "api_key", "apikey",
        "auth", "jwt", "oauth", "encrypt", "decrypt", "hash", "salt",
        "credentials", "private_key", "access_key", "signature"
    ]

    # Patterns that suggest hardcoded secrets (critical)
    HARDCODED_PATTERN = re.compile(
        r'(password|token|secret|api_key|apikey)\s*=\s*["\'][^"\']{4,}["\']',
        re.IGNORECASE
    )

    SECURITY_IMPORTS = re.compile(
        r'import.*(jwt|crypto|bcrypt|hashlib|hmac|ssl|cryptography|passlib)',
        re.IGNORECASE
    )

    score = 0

    for line in added_lines:
        l = line.lower()
        if any(k in l for k in SECURITY_KEYWORDS):
            score += 2
        if HARDCODED_PATTERN.search(line):
            score += 3
        if SECURITY_IMPORTS.search(line):
            score += 1

    for line in removed_lines:
        l = line.lower()
        if any(k in l for k in SECURITY_KEYWORDS):
            score += 1   # removing security code is risky but less so than adding

    return min(10, score)


def _score_performance(added_lines: list[str], removed_lines: list[str]) -> int:
    """
    Scores 0-10 based on:
    - Nested loops introduced in added lines        (+3 each)
    - N+1 query risk: DB call inside a loop         (+3)
    - Unindexed/raw queries added                   (+2 each)
    - Cache usage added (positive signal — lowers)  (-2 each)
    - Async/await added (positive signal)           (-1 each)
    - Heavy compute patterns added (sort, groupby)  (+1 each)

    Score represents risk level — higher = more performance concern.
    """
    score = 0
    inside_loop = False

    LOOP_PATTERN      = re.compile(r'^\s*(for |while )')
    QUERY_PATTERN     = re.compile(r'(SELECT|\.query\(|\.filter\(|\.find\(|db\.)', re.IGNORECASE)
    CACHE_PATTERN     = re.compile(r'(cache|redis|memcache|lru_cache|@cache)', re.IGNORECASE)
    ASYNC_PATTERN     = re.compile(r'\b(async def|await )\b')
    HEAVY_PATTERN     = re.compile(r'\.(sort|groupby|merge|join|aggregate)\(', re.IGNORECASE)

    for i, line in enumerate(added_lines):
        if LOOP_PATTERN.match(line):
            inside_loop = True
            score += 1

        if inside_loop and QUERY_PATTERN.search(line):
            score += 3   # DB call inside loop = N+1 risk

        if QUERY_PATTERN.search(line) and not inside_loop:
            score += 1

        if CACHE_PATTERN.search(line):
            score -= 2   # caching reduces perf risk

        if ASYNC_PATTERN.search(line):
            score -= 1   # async is good

        if HEAVY_PATTERN.search(line):
            score += 1

        # Reset loop context heuristic on dedent (blank line or lower indent)
        if inside_loop and line.strip() == '':
            inside_loop = False

    return min(10, max(0, score))


def _score_complexity(
    added_lines: list[str],
    removed_lines: list[str],
    functions_changed: int,
    files_changed: int
) -> int:
    """
    Scores 0-10 based on cognitive complexity signals:
    - Each new function/class definition             (+1)
    - Each new branch (if/elif/else/except/case)     (+1)
    - Each new loop (for/while)                      (+1)
    - Each new lambda / comprehension                (+1)
    - Deep nesting (4+ leading spaces per level)     (+1 per deeply nested line)
    - Net lines added (size proxy)                   (scaled)

    Removing code (negative net) slightly lowers score.
    """
    score = 0

    BRANCH_PATTERN  = re.compile(r'^\s*(if |elif |else:|except|except |case )')
    LOOP_PATTERN    = re.compile(r'^\s*(for |while )')
    DEF_PATTERN     = re.compile(r'^\s*(def |class |async def )')
    LAMBDA_PATTERN  = re.compile(r'\blambda\b|(\[.+for.+in.+\])|(\{.+for.+in.+\})')
    DEEP_INDENT     = re.compile(r'^\s{16,}')  # 4+ levels of 4-space indent

    for line in added_lines:
        if DEF_PATTERN.match(line):
            score += 1
        if BRANCH_PATTERN.match(line):
            score += 1
        if LOOP_PATTERN.match(line):
            score += 1
        if LAMBDA_PATTERN.search(line):
            score += 1
        if DEEP_INDENT.match(line):
            score += 1

    # Net size contribution (every 15 net new lines = +1)
    net_lines = len(added_lines) - len(removed_lines)
    score += max(0, net_lines // 15)

    return min(10, max(0, score))


def _score_stability(
    added_lines: list[str],
    removed_lines: list[str],
    files_changed: int,
    patch: PatchSet
) -> int:
    """
    Scores 0-10. Higher = more destabilising change.

    Factors:
    - Number of files changed                        (scaled, max 3 pts)
    - Config/env/infra files touched                 (+2 each)
    - High churn ratio (removed / total lines)       (scaled, max 3 pts)
    - Database migration files touched               (+2)
    - Public API surface changed (routes, endpoints) (+2)
    - Pure additions with no removals (low churn)    (-2, stable addition)
    """
    score = 0

    CONFIG_PATTERN    = re.compile(r'\.(env|yaml|yml|toml|ini|cfg|conf|json)$', re.IGNORECASE)
    MIGRATION_PATTERN = re.compile(r'(migration|migrate|alembic|schema)', re.IGNORECASE)
    ROUTE_PATTERN     = re.compile(r'(@app\.(get|post|put|delete|patch)|router\.|@router)', re.IGNORECASE)

    # File count contribution
    score += min(3, files_changed)

    for patched_file in patch:
        fname = patched_file.path or ""

        if CONFIG_PATTERN.search(fname):
            score += 2

        if MIGRATION_PATTERN.search(fname):
            score += 2

    # Churn ratio
    total = len(added_lines) + len(removed_lines)
    if total > 0:
        churn_ratio = len(removed_lines) / total
        score += int(churn_ratio * 3)   # max 3 pts from churn

    # Public API surface
    for line in added_lines + removed_lines:
        if ROUTE_PATTERN.search(line):
            score += 1

    # Pure addition (no deletions) is stable
    if len(removed_lines) == 0 and len(added_lines) > 0:
        score -= 2

    return min(10, max(0, score))


def _score_testing(
    added_lines: list[str],
    removed_lines: list[str],
    all_lines: list[str],
    patch: PatchSet
) -> int:
    """
    Scores 0-10. Higher = better test coverage in this diff.

    Factors:
    - Test file present in diff                      (+3)
    - Assert statements added                        (+1 each, max 3)
    - Mock/patch/fixture usage added                 (+1 each, max 2)
    - Test functions added (def test_)               (+1 each, max 3)
    - Code added but zero test lines                 (-3 penalty)
    - Test lines as % of total added lines           (scaled bonus)
    """
    score = 0

    TEST_FILE_PATTERN = re.compile(r'(test_|_test\.py|spec\.py|tests/)', re.IGNORECASE)
    ASSERT_PATTERN    = re.compile(r'\bassert\b|assertEqual|assertTrue|assertFalse|assertRaises', re.IGNORECASE)
    MOCK_PATTERN      = re.compile(r'\b(mock|patch|fixture|MagicMock|mocker)\b', re.IGNORECASE)
    TEST_DEF_PATTERN  = re.compile(r'def test_')

    has_test_file = False
    assert_count  = 0
    mock_count    = 0
    test_def_count = 0
    test_line_count = 0

    for patched_file in patch:
        fname = patched_file.path or ""
        if TEST_FILE_PATTERN.search(fname):
            has_test_file = True
            score += 3

    for line in added_lines:
        if ASSERT_PATTERN.search(line):
            assert_count += 1
            test_line_count += 1
        if MOCK_PATTERN.search(line):
            mock_count += 1
            test_line_count += 1
        if TEST_DEF_PATTERN.search(line):
            test_def_count += 1
            test_line_count += 1

    score += min(3, assert_count)
    score += min(2, mock_count)
    score += min(3, test_def_count)

    # Penalty: code was added but no test lines at all
    if len(added_lines) > 10 and test_line_count == 0:
        score -= 3

    # Bonus: test coverage ratio
    if len(added_lines) > 0:
        ratio = test_line_count / len(added_lines)
        score += int(ratio * 3)   # up to +3 if heavily test-weighted

    return min(10, max(0, score))


# ─────────────────────────────────────────────────────────────────────────────
# Main diff parser
# ─────────────────────────────────────────────────────────────────────────────

def analyze_diff_content(diff_text: str) -> dict:
    if not diff_text or not diff_text.strip():
        raise ValueError("Diff text is empty.")

    patch = PatchSet(diff_text)

    files_changed     = len(patch)
    functions_changed = 0
    added_lines       = []
    removed_lines     = []

    FUNC_PATTERN = re.compile(r'(def |function |class |async def )')

    for patched_file in patch:
        for hunk in patched_file:
            for line in hunk:
                text = line.value.rstrip('\n')

                if line.is_added:
                    added_lines.append(text)
                    if FUNC_PATTERN.search(text):
                        functions_changed += 1

                elif line.is_removed:
                    removed_lines.append(text)

    all_lines = added_lines + removed_lines

    # ── Five independently reasoned radar scores ──────────────────────────────
    radar = {
        "security":    _score_security(added_lines, removed_lines),
        "performance": _score_performance(added_lines, removed_lines),
        "complexity":  _score_complexity(added_lines, removed_lines, functions_changed, files_changed),
        "stability":   _score_stability(added_lines, removed_lines, files_changed, patch),
        "testing":     _score_testing(added_lines, removed_lines, all_lines, patch),
    }

    return {
        "files_changed":     files_changed,
        "lines_added":       len(added_lines),
        "lines_removed":     len(removed_lines),
        "functions_changed": functions_changed,
        "radar":             radar,
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /analyze
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/analyze")
async def analyze_diff_endpoint(request: Request, file: UploadFile = File(None)):
    diff_text = ""

    if file and file.filename:
        diff_text = (await file.read()).decode("utf-8", errors="replace")

    if not diff_text:
        try:
            body = await request.json()
            diff_text = body.get("diff", "")
        except Exception:
            pass

    if not diff_text or not diff_text.strip():
        raise HTTPException(status_code=400, detail="No diff content provided.")

    try:
        metrics = analyze_diff_content(diff_text)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    risk   = compute_risk(diff_text)
    report = analyze_diff(diff_text, risk=risk, mode="reviewer")

    return {
        "report": report,
        "stats": {
            "files":     metrics["files_changed"],
            "added":     metrics["lines_added"],
            "removed":   metrics["lines_removed"],
            "functions": metrics["functions_changed"],
        },
        "risk":  list(metrics["radar"].values()),
        "radar": metrics["radar"],
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /ask
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/ask")
async def ask_tech_assistant(data: dict):
    question = data.get("question", "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question is required.")

    result = query_tech_assistant(question)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# GET /repos/{topic}
# ─────────────────────────────────────────────────────────────────────────────

VALID_SORT_OPTIONS = {"stars", "forks", "updated", "issues", "watchers"}

@app.get("/repos/{topic}")
async def github_repos(topic: str, sort: str = "stars", language: str = None):
    if sort not in VALID_SORT_OPTIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid sort '{sort}'. Choose from: {', '.join(sorted(VALID_SORT_OPTIONS))}",
        )
    try:
        repos = search_repositories(query=topic, sort=sort, language=language or None)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"GitHub API error: {exc}")

    return repos


@app.get("/repos")
async def github_repos_empty():
    return []